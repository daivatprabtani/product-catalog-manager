import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Product, PageState } from '../core/models';
import { ProductCardComponent } from './product-card.component';
import { PaginationComponent } from './pagination.component';
@Component({selector:'app-product-list',standalone:true,imports:[ProductCardComponent,PaginationComponent],template:`
@if(state.loading){<div class="loading"><span class="spinner" role="status" aria-label="Loading products"></span></div>}@else if(state.error){<p class="notice error">{{state.error}}</p>}@else if(!state.products.length){<p class="notice">No products found.</p>}@else{
<div class="product-grid">@for(product of state.products;track product.id){<app-product-card [product]="product" (toggle)="toggle.emit($event)" (remove)="remove.emit($event)" />}</div>
<app-pagination [page]="page" [limit]="limit" [total]="state.total" (pageChange)="pageChange.emit($event)" />}`})
export class ProductListComponent { @Input({required:true}) state!:PageState;@Input() page=0;@Input() limit=10;@Output() pageChange=new EventEmitter<number>();@Output() toggle=new EventEmitter<Product>();@Output() remove=new EventEmitter<Product>(); }
