import { Component, EventEmitter, Input, Output } from '@angular/core';
@Component({selector:'app-pagination',standalone:true,template:`
<div class="pagination">
<span class="page-count">{{total ? page*limit+1 : 0}}–{{Math.min((page+1)*limit,total)}} of {{total}} products</span>
<button type="button" class="secondary" [disabled]="page === 0" (click)="pageChange.emit(page-1)">Previous</button>
<span>Page {{page+1}} of {{pages}}</span>
<button type="button" class="secondary" [disabled]="page+1 >= pages" (click)="pageChange.emit(page+1)">Next</button>
</div>`})
export class PaginationComponent {
 @Input() page=0; @Input() total=0; @Input() limit=10;
 @Output() pageChange=new EventEmitter<number>();
 readonly Math=Math;
 get pages(){return Math.max(1,Math.ceil(this.total/this.limit));}
}
