import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CurrencyPipe, DecimalPipe } from '@angular/common';
import { Product } from '../core/models';
@Component({ selector: 'app-product-card', standalone: true, imports: [CurrencyPipe, DecimalPipe], template: `
<article class="product-card">
  <div class="product-image">@if(product.thumbnail){<img [src]="product.thumbnail" [alt]="product.title">}@else{<span>No image</span>}</div>
  <div class="product-content"><small>{{ product.category }}</small><h3>{{ product.title }}</h3>
  <div class="product-meta"><strong>{{ product.price | currency }}</strong><span>★ {{ product.rating | number:'1.1-1' }}</span></div>
  <span class="stock" [class.sold]="product.outOfStock || product.stock === 0">{{ product.outOfStock || product.stock === 0 ? 'Out of stock' : 'In stock (' + product.stock + ')' }}</span>
  <div class="actions"><button type="button" class="secondary" (click)="toggle.emit(product)">Toggle stock</button><button type="button" class="danger" (click)="remove.emit(product)">Delete</button></div></div>
</article>` })
export class ProductCardComponent { @Input({ required: true }) product!: Product; @Output() toggle = new EventEmitter<Product>(); @Output() remove = new EventEmitter<Product>(); }
