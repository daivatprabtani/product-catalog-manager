import { Component, inject } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { catchError, combineLatest, forkJoin, map, of, startWith, switchMap } from 'rxjs';
import { CatalogService } from '../core/catalog.service';
@Component({standalone:true,imports:[AsyncPipe,RouterLink],template:`<div class="heading"><h1>Categories</h1><p>Browse products by category.</p></div>
@if(vm$ | async; as vm){@if(vm.loading){<div class="loading"><span class="spinner" role="status" aria-label="Loading categories"></span></div>}@else if(vm.error){<p class="notice error">{{vm.error}}</p>}@else{<div class="category-grid">@for(c of vm.categories;track c.slug){<a class="category" [routerLink]="['/categories',c.slug]"><strong>{{c.name}}</strong><span>{{c.count}} products →</span></a>}</div>}}`})
export class CategoryListComponent { private api=inject(CatalogService); vm$=this.api.categories().pipe(switchMap(categories=>forkJoin(categories.map(c=>this.api.categoryCount(c.slug).pipe(map(count=>({...c,count})),catchError(()=>of({...c,count:0})))))),map(categories=>({categories,loading:false,error:''})),startWith({categories:[],loading:true,error:''}),catchError(()=>of({categories:[],loading:false,error:'Unable to load categories.'}))); }
