import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { ProductFormComponent } from './product-form.component';

describe('ProductFormComponent', () => {
  it('rejects invalid title, price, and stock', async () => {
    await TestBed.configureTestingModule({ imports: [ProductFormComponent], providers: [provideHttpClient()] }).compileComponents();
    const component = TestBed.createComponent(ProductFormComponent).componentInstance;
    component.form.setValue({ title: 'ab', price: -1, stock: 1.5, category: 'beauty' });
    expect(component.form.invalid).toBeTrue();
    component.form.setValue({ title: 'Valid title', price: 10, stock: 2, category: 'beauty' });
    expect(component.form.valid).toBeTrue();
  });
});
