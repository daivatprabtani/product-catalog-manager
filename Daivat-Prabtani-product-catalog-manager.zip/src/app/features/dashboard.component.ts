import { Component, inject } from '@angular/core';
import { AsyncPipe, DecimalPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { combineLatest, catchError, map, of, switchMap, startWith } from 'rxjs';
import { CatalogService } from '../core/catalog.service';
@Component({standalone:true,imports:[AsyncPipe,DecimalPipe,RouterLink],template:`
<div class="heading"><h1>Dashboard</h1><p>Product catalog overview. Select a card to explore.</p></div>
@if(stats$ | async; as stats){
<div class="stats">
<a class="stat stat-link" routerLink="/categories"><span>Categories →</span><strong>{{stats.categories}}</strong><small>Browse categories</small></a>
<a class="stat stat-link" routerLink="/search"><span>Total products →</span><strong>{{stats.products}}</strong><small>Browse all products</small></a>
<a class="stat stat-link" [routerLink]="stats.lastRoute"><span>Average page price →</span><strong>{{stats.price | number:'1.2-2'}}</strong><small>{{stats.pageCount}} products in last viewed page</small></a>
<a class="stat stat-link" [routerLink]="stats.lastRoute"><span>Average page rating →</span><strong>{{stats.rating | number:'1.2-2'}}</strong><small>Return to last product list</small></a>
</div>}
<div class="links"><a routerLink="/categories">Browse categories →</a><a routerLink="/search">Search products →</a></div>`})
export class DashboardComponent {
 private api=inject(CatalogService);
 stats$=combineLatest([
   this.api.categories().pipe(map(c=>c.length),catchError(()=>of(0))),
   this.api.changes$.pipe(startWith(0),switchMap(()=>this.api.totalProducts().pipe(catchError(()=>of(0))))),
   this.api.lastPage$,
   this.api.lastRoute$
 ]).pipe(map(([categories,products,page,lastRoute])=>({
   categories,products,pageCount:page.length,lastRoute,
   price:page.length?page.reduce((s,p)=>s+p.price,0)/page.length:0,
   rating:page.length?page.reduce((s,p)=>s+p.rating,0)/page.length:0
 })));
}
