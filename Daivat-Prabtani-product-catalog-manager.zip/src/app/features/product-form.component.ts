import { Component, EventEmitter, Input, Output, inject, OnChanges } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CatalogService } from '../core/catalog.service';
@Component({standalone:true,selector:'app-product-form',imports:[ReactiveFormsModule],template:`<form class="form-panel" [formGroup]="form" (ngSubmit)="save()"><h2>Add product</h2>
<div class="form-grid"><label>Title<input formControlName="title" placeholder="Product title">@if(form.controls.title.touched && form.controls.title.invalid){<small class="error">Enter at least 3 characters.</small>}</label>
<label>Price<input type="number" formControlName="price" min="0.01">@if(form.controls.price.touched && form.controls.price.invalid){<small class="error">Enter a positive price.</small>}</label>
<label>Stock<input type="number" formControlName="stock" min="0" step="1">@if(form.controls.stock.touched && form.controls.stock.invalid){<small class="error">Enter a whole number of 0 or more.</small>}</label>
<label>Category<input formControlName="category">@if(form.controls.category.touched && form.controls.category.invalid){<small class="error">Category is required.</small>}</label></div>
@if(error){<p class="error">{{error}}</p>}<button type="submit" [disabled]="saving">{{saving?'Saving...':'Save product'}}</button></form>`})
export class ProductFormComponent implements OnChanges {
 @Input() category='';@Output() saved=new EventEmitter<void>();private fb=inject(FormBuilder);private api=inject(CatalogService);saving=false;error='';
 form=this.fb.nonNullable.group({title:['',[Validators.required,Validators.minLength(3)]],price:[0,[Validators.required,Validators.min(0.01)]],stock:[0,[Validators.required,Validators.min(0),Validators.pattern(/^\d+$/)]],category:['',Validators.required]});
 ngOnChanges(){this.form.patchValue({category:this.category});}
 save(){if(this.form.invalid){this.form.markAllAsTouched();return;}this.saving=true;this.error='';this.api.create(this.form.getRawValue()).subscribe({next:()=>{this.saving=false;this.saved.emit();this.form.reset({title:'',price:0,stock:0,category:this.category});},error:()=>{this.saving=false;this.error='Unable to add product.';}});}
}
