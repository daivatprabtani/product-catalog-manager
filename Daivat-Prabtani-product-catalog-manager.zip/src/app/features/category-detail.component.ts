import { Component, inject } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { BehaviorSubject, combineLatest, catchError, map, of, startWith, switchMap, distinctUntilChanged } from 'rxjs';
import { CatalogService } from '../core/catalog.service';
import { Product, emptyPage } from '../core/models';
import { ProductListComponent } from '../shared/product-list.component';
import { ProductFormComponent } from './product-form.component';
@Component({standalone:true,imports:[AsyncPipe,RouterLink,ProductListComponent,ProductFormComponent],template:`
<a routerLink="/categories" class="back">← Categories</a><div class="heading"><h1>{{slug}}</h1><p>Manage products in this category.</p></div>
<div class="toolbar"><label>Sort by <select [value]="sort.value" (change)="changeSort($any($event.target).value)"><option value="title:asc">Title A–Z</option><option value="price:asc">Price low to high</option><option value="price:desc">Price high to low</option><option value="rating:desc">Rating high to low</option></select></label><button (click)="showForm=!showForm">{{showForm?'Close form':'Add product'}}</button></div>
@if(showForm){<app-product-form [category]="slug" (saved)="showForm=false" />}
<label class="failure"><input type="checkbox" [checked]="api.simulateFailure" (change)="api.simulateFailure=$any($event.target).checked"> Simulate update/delete failure</label>
@if(message){<p class="notice error">{{message}}</p>}
@if(vm$ | async;as vm){<app-product-list [state]="vm" [page]="page.value" [limit]="limit" (pageChange)="page.next($event)" (toggle)="toggle($event)" (remove)="remove($event)" />}`})
export class CategoryDetailComponent {
 api=inject(CatalogService); private route=inject(ActivatedRoute);limit=8;page=new BehaviorSubject(0);sort=new BehaviorSubject('title:asc');slug='';showForm=false;message='';
 private slug$=this.route.paramMap.pipe(map(p=>p.get('slug')||''),distinctUntilChanged());
 vm$=combineLatest([this.slug$,this.page,this.sort,this.api.changes$]).pipe(switchMap(([slug,page,sort])=>{this.slug=slug;this.api.setLastRoute('/categories/'+encodeURIComponent(slug));const [field,order]=sort.split(':');return this.api.categoryProducts(slug,page,this.limit,field,order).pipe(map(r=>({products:r.products,total:r.total,loading:false,error:''})),startWith({...emptyPage}),catchError(()=>of({...emptyPage,loading:false,error:'Unable to load products.'})));}));
 constructor(){this.slug$.subscribe(()=>this.page.next(0));}
 changeSort(v:string){this.sort.next(v);this.page.next(0);}
 toggle(p:Product){this.message='';this.api.toggleStock(p).subscribe({error:()=>this.message='Unable to update stock. The change was reverted.'});}
 remove(p:Product){if(!confirm(`Delete ${p.title}?`))return;this.message='';this.api.delete(p).subscribe({error:()=>this.message='Unable to delete product. The change was reverted.'});}
}
