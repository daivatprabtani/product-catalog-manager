import { Component, inject } from '@angular/core';
import { AsyncPipe } from '@angular/common';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { BehaviorSubject, combineLatest, debounceTime, distinctUntilChanged, startWith, switchMap, map, catchError, of, tap } from 'rxjs';
import { CatalogService } from '../core/catalog.service';
import { Product, emptyPage } from '../core/models';
import { ProductListComponent } from '../shared/product-list.component';
@Component({standalone:true,imports:[AsyncPipe,ReactiveFormsModule,ProductListComponent],template:`<div class="heading"><h1>Search products</h1><p>Search across all categories.</p></div>
<input class="search-input" type="search" [formControl]="query" placeholder="Search by product name...">
@if(message){<p class="notice error">{{message}}</p>}
@if(vm$ | async;as vm){<app-product-list [state]="vm" [page]="page.value" [limit]="limit" (pageChange)="page.next($event)" (toggle)="toggle($event)" (remove)="remove($event)" />}`})
export class SearchComponent {
 private api=inject(CatalogService);constructor(){this.api.setLastRoute('/search');}query=new FormControl('',{nonNullable:true});page=new BehaviorSubject(0);limit=8;message='';
 private query$=this.query.valueChanges.pipe(startWith(''),debounceTime(300),distinctUntilChanged(),tap(()=>this.page.next(0)));
 vm$=combineLatest([this.query$,this.page,this.api.changes$]).pipe(switchMap(([q,page])=>this.api.search(q,page,this.limit).pipe(map(r=>({products:r.products,total:r.total,loading:false,error:''})),startWith({...emptyPage}),catchError(()=>of({...emptyPage,loading:false,error:'Unable to search products.'})))));
 toggle(p:Product){this.message='';this.api.toggleStock(p).subscribe({error:()=>this.message='Update failed. Change reverted.'});}
 remove(p:Product){if(!confirm(`Delete ${p.title}?`))return;this.message='';this.api.delete(p).subscribe({error:()=>this.message='Delete failed. Change reverted.'});}
}
