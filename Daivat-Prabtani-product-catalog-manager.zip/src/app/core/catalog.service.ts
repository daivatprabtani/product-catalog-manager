import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, map, tap, of } from 'rxjs';
import { Category, Product, ProductInput, ProductPage } from './models';

@Injectable({ providedIn: 'root' })
export class CatalogService {
  private http = inject(HttpClient);
  private base = 'https://dummyjson.com';
  private changes = new BehaviorSubject<number>(0);
  private added: Product[] = [];
  private removed = new Map<number, Product>();
  private modified = new Map<number, Partial<Product>>();
  private nextId = -1;
  private lastPage = new BehaviorSubject<Product[]>([]);
  readonly lastPage$ = this.lastPage.asObservable();
  readonly changes$ = this.changes.asObservable();
  private lastRoute = new BehaviorSubject<string>('/search');
  readonly lastRoute$ = this.lastRoute.asObservable();
  setLastRoute(route: string): void { this.lastRoute.next(route); }
  readonly addedProducts$ = this.changes$.pipe(map(() => [...this.added]));
  simulateFailure = false;

  categories(): Observable<Category[]> {
    return this.http.get<Category[]>(`${this.base}/products/categories`);
  }
  categoryCount(slug: string): Observable<number> {
    return this.http.get<ProductPage>(`${this.base}/products/category/${encodeURIComponent(slug)}`, { params: { limit: 1 } }).pipe(map(r => r.total + this.added.filter(p => p.category === slug).length - [...this.removed.values()].filter(p => p.category === slug).length));
  }
  totalProducts(): Observable<number> {
    return this.http.get<ProductPage>(`${this.base}/products`, { params: { limit: 1 } }).pipe(
      map(r => r.total + this.added.length - this.removed.size)
    );
  }
  categoryProducts(slug: string, page: number, limit: number, sortBy: string, order: string): Observable<ProductPage> {
    return this.loadPage(page, limit, p => p.category === slug,
      (skip, take) => this.http.get<ProductPage>(`${this.base}/products/category/${encodeURIComponent(slug)}`, {
        params: new HttpParams().set('limit', take).set('skip', skip).set('sortBy', sortBy).set('order', order)
      }), sortBy, order);
  }
  search(query: string, page: number, limit: number): Observable<ProductPage> {
    const q = query.trim().toLowerCase();
    return this.loadPage(page, limit, p => p.title.toLowerCase().includes(q),
      (skip, take) => this.http.get<ProductPage>(`${this.base}/products/search`, {
        params: new HttpParams().set('q', query).set('limit', take).set('skip', skip)
      }));
  }
  // Local products occupy the first positions; server products are still requested by skip/limit.
  // Over-fetch only enough to fill holes left by locally deleted server products.
  private loadPage(page: number, limit: number, match: (p: Product) => boolean,
    fetch: (skip: number, take: number) => Observable<ProductPage>, sortBy?: string, order?: string): Observable<ProductPage> {
    const locals = this.added.filter(match).sort((a, b) => {
      if (!sortBy) return a.id - b.id;
      const left = a[sortBy as 'title' | 'price' | 'rating'];
      const right = b[sortBy as 'title' | 'price' | 'rating'];
      const result = typeof left === 'string' && typeof right === 'string' ? left.localeCompare(right) : Number(left) - Number(right);
      return order === 'desc' ? -result : result;
    });
    const deleted = [...this.removed.values()].filter(match);
    const offset = page * limit;
    const localPage = locals.slice(offset, offset + limit);
    const serverOffset = Math.max(0, offset - locals.length);
    const needed = limit - localPage.length;
    // Deletions can create gaps in server pages; fetch enough records to fill the visible page.
    const take = Math.max(1, needed + deleted.length);
    return fetch(serverOffset, take).pipe(map(response => {
      const server = response.products.filter(p => !this.removed.has(p.id))
        .map(p => ({ ...p, ...this.modified.get(p.id) })).slice(0, needed);
      const products = [...localPage, ...server];
      const total = response.total + locals.length - deleted.length;
      this.lastPage.next(products);
      return { products, total, skip: offset, limit };
    }));
  }
  private changed(): void { this.changes.next(this.changes.value + 1); }
  create(data: ProductInput): Observable<Product> {
    const normalized = (value: string) => value.trim().toLowerCase();
    const existing = this.added.find(p => normalized(p.title) === normalized(data.title)
      && normalized(p.category) === normalized(data.category) && p.price === data.price);
    if (existing) {
      existing.stock += data.stock;
      this.changed();
      return of(existing);
    }
    return this.http.post<Product>(`${this.base}/products/add`, data).pipe(map(response => {
      const product: Product = { ...response, ...data, id: this.nextId--, rating: 0, local: true };
      this.added.unshift(product);
      this.changed();
      return product;
    }));
  }
  toggleStock(product: Product): Observable<unknown> {
    const before = this.modified.get(product.id);
    const next = !product.outOfStock;
    if (product.local) {
      this.added = this.added.map(p => p.id === product.id ? { ...p, outOfStock: next } : p);
      this.changed();
      return new Observable(sub => { sub.next(null); sub.complete(); });
    }
    this.modified.set(product.id, { ...before, outOfStock: next });
    this.changed();
    const url = this.simulateFailure ? `${this.base}/http/500` : `${this.base}/products/${product.id}`;
    return this.http.patch(url, { stock: next ? 0 : product.stock }).pipe(tap({ error: () => { if (before) this.modified.set(product.id, before); else this.modified.delete(product.id); this.changed(); } }));
  }
  delete(product: Product): Observable<unknown> {
    if (product.local) {
      this.added = this.added.filter(p => p.id !== product.id);
      this.changed();
      return new Observable(sub => { sub.next(null); sub.complete(); });
    }
    this.removed.set(product.id, product);
    this.changed();
    const url = this.simulateFailure ? `${this.base}/http/500` : `${this.base}/products/${product.id}`;
    return this.http.delete(url).pipe(tap({ error: () => { this.removed.delete(product.id); this.changed(); } }));
  }
}
