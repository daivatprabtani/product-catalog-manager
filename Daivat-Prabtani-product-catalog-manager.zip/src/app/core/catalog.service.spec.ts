import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { CatalogService } from './catalog.service';

describe('CatalogService', () => {
  let service: CatalogService;
  let http: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(CatalogService);
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());

  it('reads product total without fetching all products', () => {
    let total = 0;
    service.totalProducts().subscribe(value => total = value);
    const request = http.expectOne(r => r.url.endsWith('/products'));
    expect(request.request.params.get('limit')).toBe('1');
    request.flush({ products: [], total: 194, skip: 0, limit: 1 });
    expect(total).toBe(194);
  });

  it('combines matching locally created products', () => {
    const ids: number[] = [];
    const data = { title: 'Sample product', price: 20, stock: 5, category: 'beauty' };
    service.create(data).subscribe(product => ids.push(product.id));
    http.expectOne('https://dummyjson.com/products/add').flush({ ...data, id: 195 });
    service.create(data).subscribe(product => { ids.push(product.id); expect(product.stock).toBe(10); });
    http.expectNone('https://dummyjson.com/products/add');
    expect(ids.length).toBe(2);
    expect(ids[0]).toBe(ids[1]);
  });

  it('rolls back failed stock updates', () => {
    const product = { id: 1, title: 'Phone', price: 100, stock: 5, rating: 4, category: 'smartphones' };
    service.simulateFailure = true;
    service.toggleStock(product).subscribe({ error: () => {} });
    http.expectOne('https://dummyjson.com/http/500').flush({}, { status: 500, statusText: 'Error' });
    service.categoryProducts('smartphones', 0, 8, 'title', 'asc').subscribe(page => {
      expect(page.products[0].outOfStock).toBeFalsy();
    });
    http.expectOne(r => r.url.includes('/products/category/smartphones')).flush({ products: [product], total: 1, skip: 0, limit: 8 });
  });
});
