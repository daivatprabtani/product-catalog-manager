export interface Category { slug: string; name: string; url: string; count?: number; }
export interface Product { id: number; title: string; price: number; rating: number; stock: number; category: string; thumbnail?: string; description?: string; outOfStock?: boolean; local?: boolean; }
export type ProductInput = Pick<Product, 'title' | 'price' | 'stock' | 'category'>;
export interface ProductPage { products: Product[]; total: number; skip: number; limit: number; }
export interface PageState { products: Product[]; total: number; loading: boolean; error: string; }
export const emptyPage: PageState = { products: [], total: 0, loading: true, error: '' };
