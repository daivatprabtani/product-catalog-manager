import { Routes } from '@angular/router';
import { inject } from '@angular/core';
import { CatalogService } from './core/catalog.service';
import { catchError, map, of } from 'rxjs';
export const routes: Routes = [
 {path:'',loadComponent:()=>import('./features/dashboard.component').then(m=>m.DashboardComponent)},
 {path:'categories',loadComponent:()=>import('./features/category-list.component').then(m=>m.CategoryListComponent)},
 {path:'categories/:slug',canActivate:[route=>inject(CatalogService).categories().pipe(map(list=>list.some(c=>c.slug===route.paramMap.get('slug'))),catchError(()=>of(false)))],loadComponent:()=>import('./features/category-detail.component').then(m=>m.CategoryDetailComponent)},
 {path:'search',loadComponent:()=>import('./features/search.component').then(m=>m.SearchComponent)},
 {path:'**',redirectTo:''}
];
