import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
@Component({selector:'app-root',standalone:true,imports:[RouterLink,RouterLinkActive,RouterOutlet],template:`<header><nav class="nav"><a class="brand" routerLink="/">Product Catalog</a><div class="nav-links"><a routerLink="/" [routerLinkActiveOptions]="{exact:true}" routerLinkActive="active">Dashboard</a><a routerLink="/categories" routerLinkActive="active">Categories</a><a routerLink="/search" routerLinkActive="active">Search</a></div></nav></header><main class="container"><router-outlet /></main>`})
export class AppComponent {}
