# Product Catalog Manager

Angular application for browsing and managing products using the DummyJSON API.

## Setup

Requires Node.js 20.19+ or a compatible version supported by Angular 20.

```bash
npm install
npm start
"or we can run with"
ng serve --host=0.0.0.0 --port="On which port should we run the application locally so that we can access it from another device connected to the same local network"

```

Open http://localhost:4200.

To run tests:

```bash
npm test
```

## Features

- Dashboard with product and category statistics (Real data showing on dashboard)
- Category list with product counts
- Server-side pagination and sorting
- Global search with debounce
- Add products, merge matching local products, toggle stock, and delete products
- Clickable dashboard cards and pagination item counts jump to related page
- Loading, error handling, and rollback on failed
- Loading time showing spinner

## Implementation

Standalone Angular components, RxJS, Reactive Forms, and SCSS. HTTP requests are handled in a dedicated service. Shared changes are kept in service state without adding a state management library.

DummyJSON does not save product changes. Created products and stock/delete changes are maintained for the current session only.

The interface uses SCSS for simple styling without a UI component dependency.

Lazy Loading: Implemented lazy loading using Angular standalone components and routing to load pages only when needed, improving initial application load performance.


## Architecture & Code Explanation

- **Angular Standalone Components:** Used standalone components with reusable UI components to keep the code clean and avoid duplication.
- **State Management:** Used RxJS and service-based state management to handle product data and local changes without NgRx.
- **API Integration:** Used HttpClient with DummyJSON API for fetching products, categories, pagination, sorting, and searching.
- **RxJS:** Used `switchMap` to prevent outdated API responses and `debounceTime` for search optimization.
- **Reactive Forms:** Used for adding products with proper field validation.
- **Lazy Loading:** Used Angular routing with lazy-loaded components to improve initial loading performance.
- **Styling:** Used SCSS for simple, responsive, and maintainable UI without additional libraries.
- **Error Handling:** Added loading spinners and error messages for API requests.


## Improvements With More Time

- **Dynamic Dashboard:** Add interactive charts showing category-wise products, stock availability, average ratings, and other statistics.
- **Stock Management:** Show detailed in-stock and out-of-stock product counts with filtering.
- **Product Ratings:** Improve rating display and allow users to submit ratings and reviews.
- **Category Management:** Add options to create, edit, and delete categories dynamically.
- **Product Management:** Add product editing, image upload, multiple product images, and more product details.
- **Advanced Filtering:** Add price-range selection, category filters, stock availability filters, and rating-based filtering.
- **Backend Integration:** Use a real backend and database to permanently save product and category changes.
- **Testing:** Add more unit and end-to-end tests for better reliability.

- Due to limited time, I focused on the main requirements, API integration, and reusable components instead of advanced UI features.

- DummyJSON does not permanently store product changes, so create, update, and delete operations are managed locally during the current session.
